
for (let i  =  5; i  <  16;  i++){
    setTimeout(console.log.bind(console, i), 0);       
        }


   